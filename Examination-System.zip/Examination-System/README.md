# Online-Examination-System
This project is developed using java server pages (jsp) and MySQL is used for backend.
IDE is the Netbeans.
sql script is included in "db script" folder.
Please create:
exam_system as a database schema.

database settings are in DatabaseClass.java.
you can modify it or default settings are:
db name:  exam_system
user:     root
pass:     root

insert your first user into the database and use the application.
Thanks
